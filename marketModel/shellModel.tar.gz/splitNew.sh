touch a.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > a.txt
touch b.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > b.txt
touch c.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > c.txt
touch d.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > d.txt
touch e.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > e.txt
touch f.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > f.txt
touch g.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > g.txt
touch h.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > h.txt
touch i.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > i.txt
touch j.txt
echo amtProduced_need, avg_price, sd, consumption_rate, consumed, char > j.txt
grep A results.txt >> a.txt
grep B results.txt >> b.txt
grep C results.txt >> c.txt
grep D results.txt >> d.txt
grep E results.txt >> e.txt
grep F results.txt >> f.txt
grep G results.txt >> g.txt
grep H results.txt >> h.txt
grep I results.txt >> i.txt
grep J results.txt >> j.txt
